import { Link } from 'react-router-dom'
import { hospitalInfo } from '../../data/hospitalInfo'

const Footer = () => {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="bg-healthcare-900 text-white">
      {/* Main Footer Content */}
      <div className="container py-12 md:py-16 lg:py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 md:gap-6 lg:gap-8 mb-12">
          {/* Hospital Info */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-healthcare-100 rounded-lg flex items-center justify-center text-healthcare-900 font-bold">
                R
              </div>
              <div>
                <h3 className="font-bold text-white leading-tight">Rishi Care</h3>
                <p className="text-xs text-healthcare-200 leading-tight">Hospital</p>
              </div>
            </div>
            <p className="text-sm text-healthcare-100 leading-relaxed">
              Premium healthcare delivered with compassion. Trusted by thousands of families in Hyderabad and nearby communities.
            </p>
            <div className="flex gap-3 pt-2">
              <a
                href={`tel:${hospitalInfo.phone}`}
                className="inline-flex items-center gap-2 px-3 py-2 bg-healthcare-700 hover:bg-healthcare-600 rounded-lg text-sm font-semibold transition-colors"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                </svg>
                Call
              </a>
              <a
                href={`https://wa.me/${hospitalInfo.whatsapp}`}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 px-3 py-2 bg-green-600 hover:bg-green-700 rounded-lg text-sm font-semibold transition-colors"
              >
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.67-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.076 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421-7.403h-.004a9.87 9.87 0 00-4.869 1.171c-1.519.754-2.753 1.7-3.746 2.851-2.027 2.333-3.187 5.411-3.187 8.677 0 .891.085 1.79.258 2.668.172.878.461 1.708.854 2.475l2.829-9.257c.088-.274.18-.546.277-.815.097-.268.196-.533.298-.795.105-.265.213-.526.324-.782.219-.513.448-1.02.689-1.519.241-.499.491-.99.754-1.471.264-.482.537-.954.82-1.418.285-.467.577-.923.877-1.37.3-.449.606-.887.92-1.314.315-.428.633-.843.963-1.246C8.58 4.18 9.3 3.473 10.114 2.817a9.875 9.875 0 014.022.784m-.001 15.925c2.764-1.456 4.592-4.405 4.592-7.769 0-.897-.087-1.772-.252-2.624.087.278.17.555.25.83.08.277.157.556.228.837.071.282.138.565.198.85.06.287.113.575.158.865l2.816 9.179c-.369.226-.756.427-1.157.6-2.76 1.128-5.745 1.128-8.833 0" />
                </svg>
                WhatsApp
              </a>
            </div>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-semibold text-white mb-4 text-sm uppercase tracking-wider">Services</h4>
            <ul className="space-y-3">
              {[
                { to: '/services', label: 'Medical Services' },
                { to: '/doctors', label: 'Our Doctors' },
                { to: '/lab-tests', label: 'Lab Tests' },
                { to: '/conditions', label: 'Conditions' },
              ].map(link => (
                <li key={link.to}>
                  <Link
                    to={link.to}
                    className="text-healthcare-100 hover:text-white text-sm transition-colors flex items-center gap-2"
                  >
                    <span className="text-healthcare-400">→</span>
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold text-white mb-4 text-sm uppercase tracking-wider">Quick Links</h4>
            <ul className="space-y-3">
              {[
                { to: '/health-tips', label: 'Health Tips' },
                { to: '/reviews', label: 'Reviews' },
                { to: '/contact', label: 'Contact Us' },
                { to: '/admin/login', label: 'Admin Panel' },
              ].map(link => (
                <li key={link.to}>
                  <Link
                    to={link.to}
                    className="text-healthcare-100 hover:text-white text-sm transition-colors flex items-center gap-2"
                  >
                    <span className="text-healthcare-400">→</span>
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="font-semibold text-white mb-4 text-sm uppercase tracking-wider">Contact</h4>
            <div className="space-y-4 text-sm">
              <div className="flex gap-3">
                <svg className="w-5 h-5 text-healthcare-400 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
                </svg>
                <div>
                  <p className="font-semibold text-white mb-1">Address</p>
                  <p className="text-healthcare-200 leading-relaxed">{hospitalInfo.address}</p>
                </div>
              </div>
              <div className="flex gap-3">
                <svg className="w-5 h-5 text-healthcare-400 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M2 3a1 1 0 011-1h2.153a1 1 0 01.986.836l.74 4.435a1 1 0 01-.54 1.06l-1.548.773c.02.04.048.082.074.124 1.476 2.214 3.76 4.498 5.974 5.974.042.026.084.054.124.074l.773-1.548a1 1 0 011.06-.54l4.435.74a1 1 0 01.836.986V17a1 1 0 01-1 1h-2C7.82 18 2 12.18 2 5V3z" />
                </svg>
                <div>
                  <p className="font-semibold text-white mb-1">Phone</p>
                  <a href={`tel:${hospitalInfo.phone}`} className="text-healthcare-200 hover:text-white transition-colors">
                    {hospitalInfo.phone}
                  </a>
                </div>
              </div>
              <div className="flex gap-3">
                <svg className="w-5 h-5 text-healthcare-400 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z" />
                  <path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z" />
                </svg>
                <div>
                  <p className="font-semibold text-white mb-1">Email</p>
                  <a href={`mailto:${hospitalInfo.email}`} className="text-healthcare-200 hover:text-white transition-colors break-all">
                    {hospitalInfo.email}
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-healthcare-800 pt-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <p className="text-sm text-healthcare-200">
              © {currentYear} Rishi Care Hospital. All rights reserved. | <a href="/privacy" className="hover:!text-black transition-colors">Privacy Policy</a> | <a href="/terms" className="hover:!text-black transition-colors">Terms of Service</a>
            </p>
            <div className="flex items-center gap-4">
              <a href="#" className="text-healthcare-200 hover:text-white transition-colors" aria-label="Facebook">
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M8.29 20v-7.21H5.5V9.25h2.79V7.07c0-2.76 1.69-4.27 4.14-4.27 1.18 0 2.19.09 2.48.13v2.87h-1.7c-1.33 0-1.59.63-1.59 1.56v2.04h3.19l-.41 3.54h-2.78V20" />
                </svg>
              </a>
              <a href="#" className="text-healthcare-200 hover:text-white transition-colors" aria-label="Twitter">
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M6.29 18.251c7.547 0 11.675-6.253 11.675-11.675 0-.178 0-.355-.012-.53A8.348 8.348 0 0020 3.92a8.19 8.19 0 01-2.357.646 4.118 4.118 0 001.804-2.27 8.224 8.224 0 01-2.605.996 4.107 4.107 0 00-6.993 3.743 11.65 11.65 0 01-8.457-4.287 4.106 4.106 0 001.27 5.477A4.073 4.073 0 01.8 7.713v.052a4.105 4.105 0 003.292 4.022 4.095 4.095 0 01-1.853.07 4.108 4.108 0 003.834 2.85A8.233 8.233 0 01.319 16.67a11.616 11.616 0 006.29 1.84" />
                </svg>
              </a>
              <a href="#" className="text-healthcare-200 hover:text-white transition-colors" aria-label="Instagram">
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M10 0C4.477 0 0 4.477 0 10c0 5.522 4.477 10 10 10s10-4.478 10-10c0-5.523-4.477-10-10-10zm4.657 8.25h-2.537V6.814a.888.888 0 00-.888-.888h-1.78a.888.888 0 00-.889.888v1.436H7.343v1.778h1.634v2.668c0 .888.89 1.602 1.89 1.602.506 0 .979-.065 1.447-.195v-1.593c-.247.041-.508.065-.778.065a.623.623 0 01-.624-.622v-2.315h1.347v-1.778z" />
                </svg>
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}

export default Footer