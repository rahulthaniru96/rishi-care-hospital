import { useState, useEffect } from 'react'
import { Link, NavLink } from 'react-router-dom'

const navigationLinks = [
  { to: '/', label: 'Home' },
  { to: '/doctors', label: 'Doctors' },
  { to: '/services', label: 'Services' },
  { to: '/conditions', label: 'Conditions' },
  { to: '/lab-tests', label: 'Lab Tests' },
  { to: '/health-tips', label: 'Health Tips' },
  { to: '/reviews', label: 'Reviews' },
  { to: '/contact', label: 'Contact' },
]

const Navbar = () => {
  const [menuOpen, setMenuOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10)
    }

    window.addEventListener('scroll', handleScroll)

    return () => {
      window.removeEventListener('scroll', handleScroll)
    }
  }, [])

  const navLinkClass = ({ isActive }) =>
    `
    px-3 py-2
    rounded-xl
    text-sm
    font-semibold
    transition-all
    duration-200
    ${
      isActive
        ? 'text-healthcare-900 bg-healthcare-50'
        : 'text-slate-600 hover:text-healthcare-900 hover:bg-slate-50'
    }
  `

  return (
    <header
      className={`sticky top-0 z-50 bg-white transition-all duration-300 ${
        scrolled
          ? 'shadow-md border-b border-slate-100'
          : 'shadow-sm border-b border-slate-50'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <div className="flex items-center justify-between h-20 md:h-24">
          
          {/* Logo */}
          <Link
            to="/"
            className="flex items-center gap-3 flex-shrink-0 group"
          >
            <div 
            className="w-12 h-12 md:w-14 md:h-14 bg-gradient-to-br text-black from-healthcare-900 to-healthcare-700 rounded-2xl flex items-center justify-center text- font-extrabold text-xl md:text-2xl shadow-lg group-hover:scale-105 transition-all duration-200" 
            style={{ color:'black'}}
            >
              R
            </div>

            <div className="hidden sm:block">
              <div className="text-lg font-bold text-healthcare-900 leading-tight" style={{ color:'black'}}>
                Rishi Care
              </div>

              <div className="text-sm font-semibold text-healthcare-700 leading-tight" style={{ color:'black'}}>
                Hospital
              </div>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-6 xl:gap-8">
            {navigationLinks.map(link => (
              <NavLink
                key={link.to}
                to={link.to}
                className={navLinkClass}
              >
                {link.label}
              </NavLink>
            ))}
          </nav>

          {/* Right Side */}
          <div className="flex items-center gap-3">
            

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              className="lg:hidden inline-flex items-center justify-center w-11 h-11 rounded-xl hover:bg-slate-100 transition-colors"
              aria-label="Toggle menu"
            >
              {menuOpen ? (
                <svg
                  className="w-6 h-6 text-slate-900"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M6 18L18 6M6 6l12 12"
                  />
                </svg>
              ) : (
                <svg
                  className="w-6 h-6 text-slate-900"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M4 6h16M4 12h16M4 18h16"
                  />
                </svg>
              )}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {menuOpen && (
          <nav className="lg:hidden border-t border-slate-100 py-4 bg-white">
            <div className="flex flex-col gap-2">
              {navigationLinks.map(link => (
                <NavLink
                  key={link.to}
                  to={link.to}
                  onClick={() => setMenuOpen(false)}
                  className={({ isActive }) =>
                    `
                    px-4
                    py-3
                    rounded-xl
                    text-sm
                    font-semibold
                    transition-all
                    ${
                      isActive
                        ? 'bg-healthcare-50 text-healthcare-900'
                        : 'text-slate-700 hover:bg-slate-50 hover:text-healthcare-900'
                    }
                  `
                  }
                >
                  {link.label}
                </NavLink>
              ))}

              <Link
                to="/admin/login"
                onClick={() => setMenuOpen(false)}
                className="mt-3 px-4 py-3 rounded-xl text-sm font-semibold bg-healthcare-900 text-white hover:bg-healthcare-800 transition-all text-center"
              >
                Admin Login
              </Link>
            </div>
          </nav>
        )}
      </div>
    </header>
  )
}

export default Navbar