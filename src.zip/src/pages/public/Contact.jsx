import { hospitalInfo } from '../../data/hospitalInfo'

const Contact = () => {
  return (
    <div>

      {/* HEADER SECTION */}

      <section className="bg-gradient-to-br from-healthcare-900 to-healthcare-800 text-white py-10 md:py-14">
        <div className="container text-center">
          <span className="inline-block px-3 py-1 bg-healthcare-700/50 border border-healthcare-400 rounded-full text-xs font-semibold text-healthcare-100 mb-4">
            GET IN TOUCH
          </span>
          <h1 className="text-4xl md:text-5xl font-bold mb-4 leading-tight">
            Contact Us
          </h1>
          <p className="text-lg text-healthcare-100 max-w-2xl mx-auto">
            We're available 24/7 for emergencies. Reach out to us anytime.
          </p>
        </div>
      </section>

      
      {/* QUICK CONTACT BUTTONS */}
      
      <section className="py-12 md:py-16 bg-slate-50 border-b border-slate-200">
        <div className="container">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 max-w-3xl mx-auto">
            <a
              href={`tel:${hospitalInfo.phone}`}
              className="card card-md text-center group hover:shadow-hover transition-all"
            >
              <p className="text-4xl mb-3">📞</p>
              <p className="font-semibold text-slate-900 text-sm mb-1">Call Now</p>
              <p className="text-xs text-slate-600">Immediate assistance</p>
            </a>

            <a
              href={`https://wa.me/${hospitalInfo.whatsapp}`}
              target="_blank"
              rel="noreferrer"
              className="card card-md text-center group hover:shadow-hover transition-all"
            >
              <p className="text-4xl mb-3">💬</p>
              <p className="font-semibold text-slate-900 text-sm mb-1">WhatsApp</p>
              <p className="text-xs text-slate-600">Quick messaging</p>
            </a>

            <a
              href={`sms:${hospitalInfo.phone}`}
              className="card card-md text-center group hover:shadow-hover transition-all"
            >
              <p className="text-4xl mb-3">✉️</p>
              <p className="font-semibold text-slate-900 text-sm mb-1">SMS</p>
              <p className="text-xs text-slate-600">Text message</p>
            </a>

            <a
              href={hospitalInfo.googleMapsUrl}
              target="_blank"
              rel="noreferrer"
              className="card card-md text-center group hover:shadow-hover transition-all"
            >
              <p className="text-4xl mb-3">📍</p>
              <p className="font-semibold text-slate-900 text-sm mb-1">Directions</p>
              <p className="text-xs text-slate-600">Get directions</p>
            </a>
          </div>
        </div>
      </section>

      
      {/* CONTACT INFORMATION */}
      
      <section className="py-10 md:py-14 bg-white">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 max-w-5xl mx-auto">
            {/* Information */}
            <div>
              <h2 className="text-2xl font-bold text-slate-900 mb-6">Hospital Information</h2>

              {/* Address */}
              <div className="mb-8">
                <div className="flex gap-4 mb-4">
                  <div className="w-12 h-12 bg-healthcare-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <svg className="w-6 h-6 text-healthcare-900" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <div>
                    <p className="font-semibold text-slate-900 mb-1">Address</p>
                    <p className="text-slate-600 text-sm leading-relaxed">{hospitalInfo.address}</p>
                  </div>
                </div>
              </div>

              {/* Phone */}
              <div className="mb-8">
                <div className="flex gap-4 mb-4">
                  <div className="w-12 h-12 bg-healthcare-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <svg className="w-6 h-6 text-healthcare-900" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M2 3a1 1 0 011-1h2.153a1 1 0 01.986.836l.74 4.435a1 1 0 01-.54 1.06l-1.548.773c.02.04.048.082.074.124 1.476 2.214 3.76 4.498 5.974 5.974.042.026.084.054.124.074l.773-1.548a1 1 0 011.06-.54l4.435.74a1 1 0 01.836.986V17a1 1 0 01-1 1h-2C7.82 18 2 12.18 2 5V3z" />
                    </svg>
                  </div>
                  <div>
                    <p className="font-semibold text-slate-900 mb-1">Phone</p>
                    <a href={`tel:${hospitalInfo.phone}`} className="text-healthcare-900 hover:text-healthcare-700 font-semibold text-sm">
                      {hospitalInfo.phone}
                    </a>
                    <p className="text-slate-600 text-xs mt-1">Call for appointments & emergencies</p>
                  </div>
                </div>
              </div>

              {/* Email */}
              <div className="mb-8">
                <div className="flex gap-4 mb-4">
                  <div className="w-12 h-12 bg-healthcare-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <svg className="w-6 h-6 text-healthcare-900" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z" />
                      <path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z" />
                    </svg>
                  </div>
                  <div>
                    <p className="font-semibold text-slate-900 mb-1">Email</p>
                    <a href={`mailto:${hospitalInfo.email}`} className="text-healthcare-900 hover:text-healthcare-700 font-semibold text-sm break-all">
                      {hospitalInfo.email}
                    </a>
                  </div>
                </div>
              </div>

              {/* Hours */}
              <div>
                <div className="flex gap-4">
                  <div className="w-12 h-12 bg-healthcare-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <svg className="w-6 h-6 text-healthcare-900" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-11a1 1 0 10-2 0v3.586L7.707 9.293a1 1 0 00-1.414 1.414l3 3a1 1 0 001.414 0l3-3a1 1 0 00-1.414-1.414L11 10.586V7z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <div className="w-full">
                    <p className="font-semibold text-slate-900 mb-3">Working Hours</p>
                    <div className="space-y-2">
                      {hospitalInfo.hours.map(h => (
                        <div key={h.day} className="flex justify-between items-center text-sm bg-slate-50 p-2 rounded">
                          <span className="text-slate-700 font-medium">{h.day}</span>
                          <span className="text-slate-900 font-semibold">{h.time}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Google Maps */}
            <div>
              <h2 className="text-2xl font-bold text-slate-900 mb-6">Location</h2>
              <div className="rounded-2xl overflow-hidden shadow-lg border border-slate-200 h-96">
                <iframe
                  src="https://www.google.com/maps?q=17.39220101772486,78.59767307229966&z=17&output=embed"
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  loading="lazy"
                  title="Hospital Location"
                />
              </div>
              <p className="text-center text-xs text-slate-500 mt-4">
                Map not loading?{' '}
                <a
                  href={hospitalInfo.googleMapsUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="text-healthcare-900 hover:text-healthcare-700 font-semibold"
                >
                  Open in Google Maps →
                </a>
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ────────────────────────────────────────────────────────── */}
      {/* EMERGENCY BANNER */}
      {/* ────────────────────────────────────────────────────────── */}
      <section className="py-8 md:py-10 bg-emergency/10 border-y border-emergency/20">
        <div className="container">
          <div className="flex items-center gap-4 max-w-3xl mx-auto">
            <svg className="w-8 h-8 text-emergency flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
            </svg>
            <div>
              <p className="font-bold text-emergency text-lg">Medical Emergency?</p>
              <p className="text-slate-700 text-sm">Call <span className="font-semibold text-emergency">{hospitalInfo.phone}</span> immediately. We're available 24/7.</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

export default Contact