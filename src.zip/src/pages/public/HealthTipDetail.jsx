import { useParams, Link } from 'react-router-dom'
import { healthTips } from '../../data/healthTips'

const tipStyles = {
  '✅': {
    card: 'border-l-4 border-green-500 bg-white',
    icon: 'bg-green-100 text-green-600',
    title: 'Recommended',
  },
  '❌': {
    card: 'border-l-4 border-red-500 bg-white',
    icon: 'bg-red-100 text-red-600',
    title: 'Avoid',
  },
  '⚠️': {
    card: 'border-l-4 border-amber-500 bg-white',
    icon: 'bg-amber-100 text-amber-600',
    title: 'Important',
  },
}

const HealthTipDetail = () => {
  const { slug } = useParams()
  const tip = healthTips.find((t) => t.slug === slug)

  if (!tip) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-5 px-4">
        <div className="text-6xl">💡</div>

        <h2 className="text-3xl font-bold !text-slate-800">
          Health Tip Not Found
        </h2>

        <p className="!text-slate-500 text-center max-w-md">
          The article you're looking for doesn't exist or may have been removed.
        </p>

        <Link
          to="/health-tips"
          className="mt-2 rounded-xl bg-[#000080] px-6 py-3 font-semibold !text-white hover:bg-[#001F99] transition"
        >
          ← Back to Health Tips
        </Link>
      </div>
    )
  }

  return (
    <div className="pb-24 lg:pb-0">

      {/* Hero */}

      <section className="max-w-6xl mx-auto mt-10 rounded-3xl bg-gradient-to-r from-[#000066] via-[#000080] to-[#001F99] px-8 py-16 shadow-xl">

        <div className="max-w-4xl mx-auto">

          <Link
            to="/health-tips"
            className="inline-flex items-center gap-2 !text-slate-400 text-slate-300 hover:!text-white transition"
          >
            ← Back to Health Tips
          </Link>

          <h1 className="mt-5 text-5xl font-bold !text-white">
            {tip.title}
          </h1>

          <p className="mt-4 text-lg !text-slate-200 leading-relaxed">
            {tip.summary}
          </p>

        </div>

      </section>

      {/* Content */}

      <div className="max-w-5xl mx-auto px-4 py-12 space-y-6">

        {tip.tips.map((item, i) => {
          const style =
            tipStyles[item.icon] || {
              card: 'border-l-4 border-slate-400 bg-white',
              icon: 'bg-slate-100 text-slate-600',
              title: 'Health Tip',
            }

          return (
            <div
              key={i}
              className={`${style.card} rounded-3xl p-6 shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-1`}
            >
              <div className="flex items-start gap-5">

                <div
                  className={`flex h-14 w-14 flex-shrink-0 items-center justify-center rounded-2xl text-2xl ${style.icon}`}
                >
                  {item.icon}
                </div>

                <div className="flex-1">

                  <span className="inline-block rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold tracking-wide text-slate-600">
                    {style.title}
                  </span>

                  <p className="mt-3 text-[16px] leading-7 text-slate-700">
                    {item.text}
                  </p>

                </div>

              </div>
            </div>
          )
        })}

        {/* Medical Note */}

        {tip.note && (
          <div className="rounded-3xl border-l-4 border-[#000080] bg-blue-50 p-6 shadow-md">

            <div className="flex items-start gap-4">

              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#000080] text-white text-xl">
                📌
              </div>

              <div>

                <h3 className="text-lg font-bold text-[#000080]">
                  Medical Note
                </h3>

                <p className="mt-2 leading-7 text-slate-700">
                  {tip.note}
                </p>

              </div>

            </div>

          </div>
        )}

        {/* CTA */}

        <div className="rounded-3xl bg-gradient-to-r from-[#001F99] via-[#000080] to-[#000066] p-10 text-center shadow-xl">

          <h2 className="text-3xl font-bold !text-white">
            Need Professional Medical Advice?
          </h2>

          <p className="mx-auto mt-3 max-w-xl !text-slate-200">
            Consult our experienced doctors for proper diagnosis and treatment.
            Contact us today for trusted healthcare services.
          </p>

          <div className="mt-8 flex flex-col justify-center gap-4 sm:flex-row">

            <a
              href="tel:+919391156294"
              className="rounded-xl bg-white px-8 py-3 font-semibold text-[#000080] transition hover:bg-slate-100"
            >
              📞 Call Hospital
            </a>

            <a
              href="https://wa.me/919391156294"
              target="_blank"
              rel="noopener noreferrer"
              className="rounded-xl bg-green-600 px-8 py-3 font-semibold text-white transition hover:bg-green-700"
            >
              💬 WhatsApp
            </a>

          </div>

        </div>

      </div>

    </div>
  )
}

export default HealthTipDetail