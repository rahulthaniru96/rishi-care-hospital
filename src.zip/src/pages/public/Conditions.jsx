import { Link } from 'react-router-dom'
import { conditions } from '../../data/conditions'

const Conditions = () => {
  return (
    <div>
      {/* ────────────────────────────────────────────────────────── */}
      {/* HEADER SECTION */}
      {/* ────────────────────────────────────────────────────────── */}
      <section className="bg-gradient-to-br from-healthcare-900 to-healthcare-800 text-white py-16 md:py-24">
        <div className="container text-center">
          <span className="inline-block px-3 py-1 bg-healthcare-700/50 border border-healthcare-400 rounded-full text-xs font-semibold text-healthcare-100 mb-4">
            CONDITIONS TREATED
          </span>
          <h1 className="text-4xl md:text-5xl font-bold mb-4 leading-tight">
            Expertise Across Specialties
          </h1>
          <p className="text-lg text-healthcare-100 max-w-2xl mx-auto">
            We provide expert diagnosis and treatment for a wide range of medical conditions. Click on any condition to learn about symptoms and remedies.
          </p>
        </div>
      </section>

      {/* ────────────────────────────────────────────────────────── */}
      {/* CONDITIONS GRID */}
      {/* ────────────────────────────────────────────────────────── */}
      <section className="py-16 md:py-24 bg-slate-50">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {conditions.map(c => (
              <Link
                key={c.slug}
                to={`/conditions/${c.slug}`}
                className="card card-md group hover:shadow-hover hover:border-healthcare-300 transition-all duration-300 flex flex-col"
              >
                <div className="flex items-start justify-between mb-3">
                  <h3 className="font-bold text-lg text-slate-900 group-hover:text-healthcare-900 transition-colors flex-grow leading-tight">
                    {c.title}
                  </h3>
                  <svg className="w-5 h-5 text-healthcare-400 group-hover:translate-x-1 transition-transform flex-shrink-0 mt-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </div>

                <p className="text-slate-600 text-sm leading-relaxed mb-4 line-clamp-3 flex-grow">
                  {c.overview}
                </p>

                {/* Metadata */}
                <div className="flex flex-wrap gap-2 pt-4 border-t border-slate-200">
                  <span className="inline-flex items-center gap-1 text-xs bg-healthcare-100 text-healthcare-900 px-2.5 py-1 rounded-full font-medium">
                    <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M3 6a3 3 0 013-3h10a1 1 0 01.82 1.573l-7 10A1 1 0 018 18H5a3 3 0 01-3-3V6z" clipRule="evenodd" />
                    </svg>
                    {c.symptoms.length} Symptoms
                  </span>
                  <span className="inline-flex items-center gap-1 text-xs bg-success/10 text-success px-2.5 py-1 rounded-full font-medium">
                    <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M9.707 16.707a1 1 0 01-1.414 0l-6-6a1 1 0 011.414-1.414L9 14.586l5.293-5.293a1 1 0 011.414 1.414l-6 6z" clipRule="evenodd" />
                    </svg>
                    {c.remedies.length} Remedies
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ────────────────────────────────────────────────────────── */}
      {/* INFO SECTION */}
      {/* ────────────────────────────────────────────────────────── */}
      <section className="py-16 md:py-24 bg-white">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Don't See Your Condition?</h2>
            <p className="text-lg text-slate-600 mb-8">
              Our experienced doctors can help diagnose and treat a wide range of health conditions. If you have concerns about a specific condition not listed, please contact us.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="tel:+919876543210"
                className="inline-flex items-center justify-center px-8 py-3 bg-healthcare-900 text-white font-semibold rounded-lg hover:bg-healthcare-800 transition-all shadow-md hover:shadow-lg"
              >
                Call for Consultation
              </a>
              <Link
                to="/contact"
                className="inline-flex items-center justify-center px-8 py-3 border-2 border-healthcare-900 text-healthcare-900 font-semibold rounded-lg hover:bg-[#000080] hover:!text-white transition-all"
              >
                Contact Us
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

export default Conditions