import { Link } from 'react-router-dom'
import { hospitalInfo } from '../../data/hospitalInfo'
import { doctors } from '../../data/doctors'
import { services } from '../../data/services'
import { conditions } from '../../data/conditions'
import { healthTips } from '../../data/healthTips'
import Button from '../../components/ui/Button'

const Home = () => {
  return (
    <div className="pb-12">
      {/* ────────────────────────────────────────────────────────── */}
      {/* HERO SECTION */}
      {/* ────────────────────────────────────────────────────────── */}
      <section className="relative bg-gradient-to-br from-healthcare-900 via-healthcare-800 to-healthcare-900 text-white overflow-hidden">
        {/* Background decorative elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -top-40 -right-40 w-80 h-80 bg-healthcare-700 rounded-full opacity-20"></div>
          <div className="absolute -bottom-20 -left-40 w-96 h-96 bg-healthcare-800 rounded-full opacity-20"></div>
        </div>

        <div className="container relative z-10 py-14 md:py-18 lg:py-20">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-10 items-center">
            {/* Left: Content */}
            <div className="space-y-4">
              <div>
                <span className="inline-block px-3 py-1 bg-healthcare-700/50 border border-healthcare-400 text-navy rounded-full text-xs font-semibold text-healthcare-100 mb-4">
                  Trusted Healthcare Since 2020
                </span>
                <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold leading-tight">
                  Your Health, Our Purpose
                </h1>
              </div>
              <p className="text-lg md:text-xl text-slate-100 leading-relaxed max-w-md">
                World-class medical care delivered with compassion. Trusted by thousands of families across Hyderabad and surrounding regions.
              </p>
              
              {/* Quick Stats */}
              <div className="grid grid-cols-3 gap-4 pt-4">
                <div className="bg-white/10 backdrop-blur-sm border border-healthcare-400/30 rounded-lg p-4">
                  <p className="text-2xl font-bold text-healthcare-50">2</p>
                  <p className="text-xs text-healthcare-100">Specialists</p>
                </div>
                <div className="bg-white/10 backdrop-blur-sm border border-healthcare-400/30 rounded-lg p-4">
                  <p className="text-2xl font-bold text-healthcare-50">7+</p>
                  <p className="text-xs text-healthcare-100">Services</p>
                </div>
                <div className="bg-white/10 backdrop-blur-sm border border-healthcare-400/30 rounded-lg p-4">
                  <p className="text-2xl font-bold text-healthcare-50">24/7</p>
                  <p className="text-xs text-healthcare-100">Emergency</p>
                </div>
              </div>

              {/* CTA Buttons */}
              <div className="flex flex-col sm:flex-row gap-4 pt-6">
                <a
                  href={`tel:${hospitalInfo.phone}`}
                  className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-white text-healthcare-900 font-semibold rounded-lg hover:bg-healthcare-50 transition-all duration-200 shadow-lg hover:shadow-xl"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                  </svg>
                  Call Now
                </a>
                <a
                  href={`https://wa.me/${hospitalInfo.whatsapp}`}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-green-500 text-white font-semibold rounded-lg hover:bg-green-600 transition-all duration-200 shadow-lg hover:shadow-xl"
                >
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.67-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.076 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347" />
                  </svg>
                  WhatsApp
                </a>
              </div>
            </div>

            {/* Right: Visual */}
            <div className="hidden lg:flex items-center justify-center">
              <div className="relative w-full aspect-square">
                <div className="absolute inset-0 bg-gradient-to-br from-healthcare-400 to-healthcare-600 rounded-3xl opacity-20"></div>
                <div className="absolute inset-8 bg-white/5 backdrop-blur-sm border border-white/20 rounded-3xl flex items-center justify-center">
                  <div className="text-center">
                    <svg className="w-32 h-32 text-healthcare-200 mx-auto mb-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
                    </svg>
                    <p className="text-slate-100 text-sm font-semibold">Premium Healthcare</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ────────────────────────────────────────────────────────── */}
      {/* STATISTICS SECTION */}
      {/* ────────────────────────────────────────────────────────── */}
      <section className="bg-white py-10 md:py-12 border-b border-slate-100">
        <div className="container">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { icon: '👨‍⚕️', label: 'Specialists', value: '2' },
              { icon: '🏥', label: 'Services', value: '7+' },
              { icon: '📋', label: 'Conditions', value: '20+' },
              { icon: '⏰', label: 'Emergency', value: '24/7' },
            ].map((stat, i) => (
              <div key={i} className="card card-md text-center">
                <p className="text-4xl mb-3">{stat.icon}</p>
                <p className="text-2xl md:text-3xl font-bold text-healthcare-900 mb-1">{stat.value}</p>
                <p className="text-sm text-slate-600">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ────────────────────────────────────────────────────────── */}
      {/* OUR SPECIALISTS SECTION */}
      {/* ────────────────────────────────────────────────────────── */}
      <section className="py-12 md:py-14 bg-slate-50">
        <div className="container">
          <div className="max-w-2xl mx-auto text-center mb-8">
            <span className="section-label">EXPERT TEAM</span>
            <h2 className="section-title">Meet Our Specialists</h2>
            <p className="section-description">
              Internationally trained physicians with decades of expertise and a patient-first approach.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {doctors.map(doc => (
              <div key={doc.id} className="card card-md group">
                <div className="flex flex-col items-center text-center">
                  <div className="w-24 h-24 rounded-full overflow-hidden mb-4 border-4 border-healthcare-100 shadow-md group-hover:shadow-lg transition-shadow">
                    <img
                      src={doc.photo}
                      alt={doc.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <h3 className="font-bold text-lg text-slate-900 mb-1">{doc.name}</h3>
                  <p className="text-sm font-semibold text-healthcare-900 mb-2">{doc.qualifications}</p>
                  <p className="text-sm text-slate-600 mb-4">{doc.specialization}</p>
                  <div className="flex flex-wrap justify-center gap-2 mb-4">
                    {doc.specialties.slice(0, 2).map(s => (
                      <span key={s} className="badge">{s}</span>
                    ))}
                  </div>
                  <Link
                    to="/doctors"
                    className="text-healthcare-900 text-sm font-semibold hover:text-healthcare-700 transition-colors flex items-center gap-1"
                  >
                    View Profile →
                  </Link>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-8">
            <Link to="/doctors">
              <Button variant="outline">View All Doctors</Button>
            </Link>
          </div>
        </div>
      </section>

      {/* ────────────────────────────────────────────────────────── */}
      {/* SERVICES SECTION */}
      {/* ────────────────────────────────────────────────────────── */}
      <section className="py-12 md:py-14 bg-white">
        <div className="container">
          <div className="max-w-2xl mx-auto text-center mb-8">
            <span className="section-label">WHAT WE OFFER</span>
            <h2 className="section-title">Our Medical Services</h2>
            <p className="section-description">
              Comprehensive healthcare under one roof with state-of-the-art facilities.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
            {services.map(s => (
              <div key={s.id} className="card card-md text-center group hover:border-healthcare-200 hover:shadow-hover">
                <p className="text-5xl mb-4 group-hover:scale-110 transition-transform">{s.icon}</p>
                <h3 className="font-bold text-lg text-slate-900 mb-2">{s.title}</h3>
                <p className="text-sm text-slate-600">{s.description || 'Expert care and treatment'}</p>
              </div>
            ))}
          </div>

          <div className="text-center">
            <Link to="/services">
              <Button variant="outline">View All Services</Button>
            </Link>
          </div>
        </div>
      </section>

      {/* ────────────────────────────────────────────────────────── */}
      {/* CONDITIONS SECTION */}
      {/* ────────────────────────────────────────────────────────── */}
      <section className="py-12 md:py-14 bg-slate-50">
        <div className="container">
          <div className="max-w-2xl mx-auto text-center mb-8">
            <span className="section-label">CONDITIONS TREATED</span>
            <h2 className="section-title">Expertise Across Specialties</h2>
            <p className="section-description">
              We provide expert diagnosis and treatment for a wide range of medical conditions.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
            {conditions.slice(0, 6).map(c => (
              <Link
                key={c.slug}
                to={`/conditions/${c.slug}`}
                className="card card-md group hover:border-healthcare-300 hover:shadow-hover transition-all"
              >
                <div className="flex items-start justify-between mb-3">
                  <h3 className="font-bold text-lg text-slate-900 group-hover:text-healthcare-900 transition-colors">
                    {c.title}
                  </h3>
                  <svg className="w-5 h-5 text-healthcare-400 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </div>
                <p className="text-sm text-slate-600 mb-4">{c.description}</p>
                <span className="text-healthcare-900 text-xs font-semibold">Learn more →</span>
              </Link>
            ))}
          </div>

          <div className="text-center">
            <Link to="/conditions">
              <Button variant="outline">View All Conditions</Button>
            </Link>
          </div>
        </div>
      </section>

      {/* ────────────────────────────────────────────────────────── */}
      {/* HEALTH TIPS PREVIEW */}
      {/* ────────────────────────────────────────────────────────── */}
      <section className="py-12 md:py-14 bg-white">
        <div className="container">
          <div className="max-w-2xl mx-auto text-center mb-8">
            <span className="section-label">WELLNESS BLOG</span>
            <h2 className="section-title">Health Tips & Advice</h2>
            <p className="section-description">
              Evidence-based health information and wellness tips for a healthier lifestyle.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {healthTips.slice(0, 3).map(tip => (
              <Link
                key={tip.slug}
                to={`/health-tips/${tip.slug}`}
                className="card overflow-hidden group hover:shadow-hover transition-all"
              >
                <div className="h-48 bg-gradient-to-br from-healthcare-100 to-healthcare-50 flex items-center justify-center group-hover:bg-gradient-to-br group-hover:from-healthcare-200 group-hover:to-healthcare-100 transition-all">
                  <span className="text-5xl">{tip.icon || '💚'}</span>
                </div>
                <div className="card-md">
                  <h3 className="font-bold text-lg text-slate-900 mb-2 group-hover:text-healthcare-900 transition-colors">
                    {tip.title}
                  </h3>
                  <p className="text-sm text-slate-600 mb-4 line-clamp-2">{tip.summary}</p>
                  <span className="text-healthcare-900 text-xs font-semibold group-hover:translate-x-1 transition-transform inline-block">
                    Read Article →
                  </span>
                </div>
              </Link>
            ))}
          </div>

          <div className="text-center">
            <Link to="/health-tips">
              <Button variant="outline">View All Tips</Button>
            </Link>
          </div>
        </div>
      </section>

      {/* ────────────────────────────────────────────────────────── */}
      {/* PATIENT TESTIMONIALS PREVIEW */}
      {/* ────────────────────────────────────────────────────────── */}
      <section className="py-12 md:py-14 bg-healthcare-50">
        <div className="container">
          <div className="max-w-2xl mx-auto text-center mb-8">
            <span className="section-label">PATIENT STORIES</span>
            <h2 className="section-title">Trusted by Our Community</h2>
            <p className="section-description">
              Real experiences from families we've had the privilege to care for.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            {[
              {
                rating: 5,
                text: "Excellent care and professional staff. Dr. Rao's diagnosis was quick and accurate.",
                author: "Rajesh Kumar",
                condition: "Patient, 2025",
              },
              {
                rating: 5,
                text: "Very compassionate team. They made my daughter comfortable during her treatment.",
                author: "Priya Sharma",
                condition: "Parent, 2025",
              },
              {
                rating: 5,
                text: "Best orthopedic care in the area. Recovery has been smooth thanks to Dr. Kumar.",
                author: "Manish Bhat",
                condition: "Post-operative, 2025",
              },
            ].map((review, i) => (
              <div key={i} className="card card-md">
                <div className="flex gap-1 mb-3">
                  {[...Array(review.rating)].map((_, j) => (
                    <span key={j} className="text-yellow-400">★</span>
                  ))}
                </div>
                <p className="text-slate-700 mb-4 italic leading-relaxed">"{review.text}"</p>
                <p className="font-semibold text-slate-900 mb-1">{review.author}</p>
                <p className="text-xs text-slate-500">{review.condition}</p>
              </div>
            ))}
          </div>

          <div className="text-center">
            <Link to="/reviews">
              <Button variant="outline">View All Reviews</Button>
            </Link>
          </div>
        </div>
      </section>

      {/* ────────────────────────────────────────────────────────── */}
      {/* CONTACT CTA SECTION */}
      {/* ────────────────────────────────────────────────────────── */}
      <section className="py-16 md:py-24 bg-gradient-to-r from-healthcare-900 to-healthcare-800 text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-0 w-96 h-96 bg-white rounded-full blur-3xl"></div>
        </div>
        <div className="container relative z-10">
          <div className="max-w-2xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Experience Premium Care?</h2>
            <p className="text-lg text-healthcare-100 mb-8">
              Contact us today to schedule your appointment or visit us at our clinic.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a href={`tel:${hospitalInfo.phone}`} className="px-8 py-3 bg-white text-healthcare-900 font-semibold rounded-lg hover:bg-healthcare-50 transition-all shadow-lg">
                Call: {hospitalInfo.phone}
              </a>
              <Link to="/contact" className="px-8 py-3 bg-healthcare-700 text-white font-semibold rounded-lg hover:bg-healthcare-600 transition-all border border-healthcare-600">
                Get Directions
              </Link>
            </div>
            <p className="text-sm text-healthcare-200 mt-6">
              📍 {hospitalInfo.address}
            </p>
          </div>
        </div>
      </section>
    </div>
  )
}

export default Home