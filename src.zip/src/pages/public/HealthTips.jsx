import { Link } from 'react-router-dom'
import { healthTips } from '../../data/healthTips'

const iconMap = {
  'prevent-kidney-stones': '🫘',
  'diabetes-awareness': '🩸',
  'bp-management': '❤️',
  'dengue-prevention': '🦟',
}

const categoryMap = {
  'prevent-kidney-stones': 'Kidney Health',
  'diabetes-awareness': 'Diabetes',
  'bp-management': 'Heart Care',
  'dengue-prevention': 'Prevention',
}

const HealthTips = () => {
  return (
    <div className="pb-24 lg:pb-0">

      {/* Hero */}
      <section className="max-w-6xl mx-auto mt-10 rounded-3xl bg-gradient-to-r from-[#000066] via-[#000080] to-[#001F99] px-8 py-16 text-center shadow-xl">
        <h1 className="!text-white text-5xl font-bold mb-3">
          Health Tips
        </h1>

        <p className="!text-slate-200 text-lg">
          Simple, practical advice for a healthier life.
        </p>
      </section>

      {/* Cards */}
      <section className="py-14 px-4">
        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8">

          {healthTips.map((tip) => (
            <Link
              key={tip.slug}
              to={`/health-tips/${tip.slug}`}
              className="group relative overflow-hidden rounded-3xl border border-slate-200 bg-white p-7 shadow-md transition-all duration-300 hover:-translate-y-2 hover:border-[#000080] hover:shadow-2xl"
            >

              {/* Decorative Background */}
              <div className="absolute -right-8 -top-8 h-28 w-28 rounded-full bg-blue-50 opacity-70 group-hover:scale-125 transition duration-500"></div>

              {/* Header */}
              <div className="relative flex items-center gap-4">

                <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-[#000066] via-[#000080] to-[#1E3A8A] text-3xl shadow-lg">
                  {iconMap[tip.slug] || '💡'}
                </div>

                <div>

                  <span className="inline-block rounded-full bg-blue-50 px-3 py-1 text-xs font-semibold tracking-wide text-[#000080]">
                    {categoryMap[tip.slug] || 'Health'}
                  </span>

                  <h3 className="mt-2 text-2xl font-bold text-slate-900 group-hover:text-[#000080] transition-colors">
                    {tip.title}
                  </h3>

                </div>

              </div>

              {/* Description */}

              <p className="relative mt-6 text-[15px] leading-7 text-slate-600">
                {tip.summary}
              </p>

              {/* Footer */}

              <div className="relative mt-8 flex items-center justify-between">

                <span className="text-sm font-semibold text-[#000080] group-hover:translate-x-1 transition-transform">
                  Read Full Article →
                </span>

                <span className="rounded-full bg-slate-100 px-3 py-1 text-xs text-slate-500">
                  2 min read
                </span>

              </div>

            </Link>
          ))}

        </div>
      </section>

    </div>
  )
}

export default HealthTips