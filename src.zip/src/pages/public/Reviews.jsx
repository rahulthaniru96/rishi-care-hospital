import { hospitalInfo } from '../../data/hospitalInfo'

const Reviews = () => {
  return (
    <div>
      
      {/* HEADER SECTION */}
      
      <section className="bg-gradient-to-br from-healthcare-900 to-healthcare-800 text-white py-16 md:py-24">
        <div className="container text-center">
          <span className="inline-block px-3 py-1 bg-healthcare-700/50 border border-healthcare-400 rounded-full text-xs font-semibold text-healthcare-100 mb-4">
            PATIENT STORIES
          </span>
          <h1 className="text-4xl md:text-5xl font-bold mb-4 leading-tight">
            Trusted by Our Community
          </h1>
          <p className="text-lg text-healthcare-100 max-w-2xl mx-auto">
            Real experiences from patients and families we've had the privilege to care for.
          </p>
        </div>
      </section>

      {/* ────────────────────────────────────────────────────────── */}
      {/* RATINGS SHOWCASE */}
      {/* ────────────────────────────────────────────────────────── */}
      <section className="py-16 md:py-24 bg-slate-50">
        <div className="container max-w-2xl mx-auto text-center">
          {/* Star Rating */}
          <div className="mb-6">
            <div className="flex justify-center gap-1 mb-4">
              {[...Array(5)].map((_, i) => (
                <div style={{ color: '#facc15' }}>
                  <svg key={i} className="w-8 h-8 text-yellow-400" fill="currentColor" viewBox="0 0 20 20" style={{ color: '#facc15' }}>
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l１．０７-３．２９２z" />
                </svg>
                </div>
              ))}
            </div>
            <p className="text-4xl font-bold text-slate-900 mb-2">4.9 / 5.0</p>
            <p className="text-lg text-slate-600">Exceptional Patient Care</p>
          </div>

          {/* Description */}
          <p className="text-slate-600 text-center mb-8">
            Patients consistently praise our doctors' expertise, caring staff, and modern facilities. Read what they have to say on Google Reviews.
          </p>

          {/* Google Reviews Link */}
          <a
            href={`https://search.google.com/local/reviews?placeid=${hospitalInfo.googlePlaceId}`}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-3 px-8 py-4 bg-white border-2 border-slate-200 hover:border-healthcare-200 hover:shadow-lg rounded-lg transition-all group"
          >
            <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none">
              <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
              <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
              <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05"/>
              <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
            </svg>
            <div className="text-left">
              <p className="font-bold text-slate-900 group-hover:text-healthcare-900 transition-colors">View on Google</p>
              <p className="text-xs text-slate-600">Read verified patient reviews</p>
            </div>
          </a>
        </div>
      </section>

      {/* ────────────────────────────────────────────────────────── */}
      {/* TESTIMONIALS */}
      {/* ────────────────────────────────────────────────────────── */}
      <section className="py-16 md:py-24 bg-white">
        <div className="container">
          <div className="max-w-2xl mx-auto text-center mb-12">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">What Patients Say</h2>
            <p className="text-slate-600">
              These testimonials reflect our commitment to excellent healthcare and compassionate patient care.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {[
              {
                rating: 5,
                text: "Excellent care from the moment I walked in. The doctors are very knowledgeable and the staff is incredibly helpful. Highly recommend!",
                author: "Rajesh Kumar",
                type: "Patient",
                icon: "👨‍💼",
              },
              {
                rating: 5,
                text: "My daughter was treated with so much care and attention. The diagnosis was quick and accurate. We're very grateful to the entire team.",
                author: "Priya Sharma",
                type: "Parent",
                icon: "👩‍👧",
              },
              {
                rating: 5,
                text: "Best orthopedic care I've received. Dr. Kumar is a fantastic surgeon and the recovery has been smooth. Thank you!",
                author: "Manish Bhat",
                type: "Post-operative",
                icon: "👨‍⚕️",
              },
            ].map((review, i) => (
              <div key={i} className="card card-md">
                <div className="flex gap-1 mb-4">
                  {[...Array(review.rating)].map((_, j) => (
                    <svg key={j} className="w-4 h-4 text-yellow-400" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                </div>
                <p className="text-slate-700 mb-4 italic leading-relaxed">"{review.text}"</p>
                <div className="border-t border-slate-200 pt-4">
                  <p className="font-semibold text-slate-900 text-sm">{review.author}</p>
                  <p className="text-xs text-slate-500">{review.type}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ────────────────────────────────────────────────────────── */}
      {/* WRITE REVIEW SECTION */}
      {/* ────────────────────────────────────────────────────────── */}
      <section className="py-16 md:py-24 bg-healthcare-50 border-y border-healthcare-200">
        <div className="container">
          <div className="max-w-2xl mx-auto text-center">
            <div className="mb-6">
              <svg className="w-16 h-16 mx-auto text-healthcare-900 mb-4 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M7 8h10M7 12h4m1 8l-4-4H5a2 2 0 01-2-2V5a2 2 0 012-2h14a2 2 0 012 2v12a2 2 0 01-2 2l-4 4v-4z" />
              </svg>
            </div>
            <h2 className="text-3xl font-bold text-slate-900 mb-3">Share Your Experience</h2>
            <p className="text-slate-600 mb-8">
              Had a great experience with us? Your review helps other patients find trustworthy healthcare. Please share your feedback on Google.
            </p>
            <a
              href={hospitalInfo.googleReviewLink}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 px-8 py-3 bg-healthcare-900 text-white font-semibold rounded-lg hover:bg-healthcare-800 transition-all shadow-lg hover:shadow-xl"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
              </svg>
              Write a Review
            </a>
          </div>
        </div>
      </section>
    </div>
  )
}

export default Reviews