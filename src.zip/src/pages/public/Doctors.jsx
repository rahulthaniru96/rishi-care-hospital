import { doctors } from '../../data/doctors'
import { hospitalInfo } from '../../data/hospitalInfo'
import Button from '../../components/ui/Button'

const Doctors = () => {
  return (
    <div>
      {/* ────────────────────────────────────────────────────────── */}
      {/* HEADER SECTION */}
      {/* ────────────────────────────────────────────────────────── */}
      <section className="bg-gradient-to-br from-healthcare-900 to-healthcare-800 text-white py-16 md:py-24">
        <div className="container text-center">
          <span className="inline-block px-3 py-1 bg-healthcare-700/50 border border-healthcare-400 rounded-full text-xs font-semibold text-healthcare-100 mb-4">
            EXPERT TEAM
          </span>
          <h1 className="text-4xl md:text-5xl font-bold mb-4 leading-tight">
            Meet Our Specialists
          </h1>
          <p className="text-lg text-healthcare-100 max-w-2xl mx-auto">
            Internationally trained physicians with decades of expertise dedicated to providing compassionate, comprehensive care.
          </p>
        </div>
      </section>

      {/* ────────────────────────────────────────────────────────── */}
      {/* DOCTORS GRID */}
      {/* ────────────────────────────────────────────────────────── */}
      <section className="py-16 md:py-24 bg-slate-50">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {doctors.map(doc => (
              <div key={doc.id} className="card overflow-hidden group hover:shadow-hover transition-all duration-300">
                {/* Image Section */}
                <div className="aspect-square overflow-hidden bg-gradient-to-br from-healthcare-100 to-healthcare-50 relative">
                  <img
                    src={doc.photo}
                    alt={doc.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/30 via-transparent to-transparent"></div>
                </div>

                {/* Content Section */}
                <div className="card-md">
                  <div className="mb-3">
                    <h2 className="text-xl font-bold text-slate-900 mb-1 group-hover:text-healthcare-900 transition-colors">
                      {doc.name}
                    </h2>
                    <p className="text-sm font-semibold text-healthcare-900 mb-2">
                      {doc.qualifications}
                    </p>
                    <p className="text-sm text-slate-600 mb-3">
                      {doc.specialization}
                    </p>
                  </div>

                  {/* Specialties */}
                  <div className="flex flex-wrap gap-2 mb-4 pb-4 border-b border-slate-200">
                    {doc.specialties.map(s => (
                      <span key={s} className="badge">{s}</span>
                    ))}
                  </div>

                  {/* Availability */}
                  <div className="mb-4 p-3 bg-healthcare-50 border border-healthcare-100 rounded-lg">
                    <p className="text-xs text-slate-600 mb-1">
                      <span className="font-semibold text-healthcare-900">Availability</span>
                    </p>
                    <p className="text-sm text-slate-700">{doc.available}</p>
                  </div>

                  {/* CTA Buttons */}
                  <div className="flex gap-3">
                    <a
                      href={`tel:${hospitalInfo.phone}`}
                      className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2 bg-healthcare-900 text-white font-semibold text-sm rounded-lg hover:bg-healthcare-800 transition-all"
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                      </svg>
                      Call
                    </a>
                    <a
                      href={`https://wa.me/${hospitalInfo.whatsapp}`}
                      target="_blank"
                      rel="noreferrer"
                      className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2 bg-green-600 text-white font-semibold text-sm rounded-lg hover:bg-green-700 transition-all"
                    >
                      <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.67-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.076 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347" />
                      </svg>
                      Chat
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ────────────────────────────────────────────────────────── */}
      {/* CTA SECTION */}
      {/* ────────────────────────────────────────────────────────── */}
      <section className="py-16 md:py-24 bg-white">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
              Ready to Schedule Your Consultation?
            </h2>
            <p className="text-lg text-slate-600 mb-8">
              Our doctors are ready to help you achieve your health goals. Contact us today to book your appointment.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href={`tel:${hospitalInfo.phone}`}
                className="inline-flex items-center justify-center px-8 py-3 bg-healthcare-900 text-white font-semibold rounded-lg hover:bg-healthcare-800 transition-all shadow-md hover:shadow-lg"
              >
                Call Now: {hospitalInfo.phone}
              </a>
              <a
                href={`https://wa.me/${hospitalInfo.whatsapp}`}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center justify-center px-8 py-3 bg-green-600 text-white font-semibold rounded-lg hover:bg-green-700 transition-all shadow-md hover:shadow-lg"
              >
                Message on WhatsApp
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

export default Doctors